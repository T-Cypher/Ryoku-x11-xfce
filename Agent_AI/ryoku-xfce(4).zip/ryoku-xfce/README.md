# Ryoku → Quickshell (XFCE / xfwm4 / X11)

A **Quickshell** conversion of the [Ryoku](https://github.com/Ryoku-dev/ryoku) desktop
shell, built to run on **Arch Linux + XFCE (xfwm4) on X11** instead of Ryoku's
Wayland/Hyprland + Go-daemon stack.

It keeps Ryoku's visual language — the **Solitude Dark** near-black palette, the
monochrome "sumi" rail, the warm-coral (`#de6145`) accent, and the rounded,
translucent floating panels — but re-implements every data source with portable
Quickshell modules and standard Arch tooling, so there is **nothing to build** and
**no Ryoku packages required**.

> Why a conversion and not the real thing? Ryoku's shell is one big QML tree driven
> by a Go IPC daemon (`ryoku-shell`) and tied to Hyprland/Wayland protocols
> (layer-shell, screencopy, foreign-toplevel). Those don't exist on plain XFCE/X11.
> This config reproduces the *experience* with Quickshell's cross-platform
> `PanelWindow` (which maps to an X11 dock with `_NET_WM_STRUT_PARTIAL`) and the
> `Mpris` / `SystemTray` / `UPower` / `DesktopEntries` services.

## What you get

| Surface | Description |
| --- | --- |
| **Pill bar** (one per monitor) | Launcher button · xfwm4 workspace pips · active-window title · clock/date · media · network · volume · brightness · battery · system tray · control-center & power buttons |
| **Control Center** | Wi-Fi / Bluetooth / Night-Light / Power-Profile quick toggles, volume & brightness sliders, a now-playing card, and power actions |
| **Launcher** | Fuzzy-searchable `.desktop` app grid (keyboard driven) |
| **Power Menu** | Lock / Logout / Sleep / Reboot / Shut via XFCE session tools |

Everything is clickable; the keyboard shortcuts below are optional.

## Install

```bash
# 1. Dependencies (Arch)
sudo pacman -S quickshell pipewire wireplumber pipewire-pulse \
    networkmanager brightnessctl bluez bluez-utils upower \
    wmctrl xdotool redshift power-profiles-daemon

# 2. Install this config
cd ryoku-xfce
./install.sh          # copies into ~/.config/quickshell + adds XFCE autostart

# 3. Run it
qs -c ryoku-xfce
```

Named config installed to `~/.config/quickshell/ryoku-xfce/` (previous config is backed up). See `CHANGELOG-continuation.md` for v0.2 fixes/additions (Calendar, OSD, XFCE setup/restore scripts).

## Keybindings (XFCE)

XFCE → **Settings → Keyboard → Application Shortcuts**, add:

| Keys | Command |
| --- | --- |
| `Super+Space` | `qs -c ryoku-xfce ipc call launcher toggle` |
| `Super+S` | `qs -c ryoku-xfce ipc call controlcenter toggle` |
| `Super+Esc` | `qs -c ryoku-xfce ipc call powermenu toggle` |

(You can also just click the bar buttons — no keybinds required.)

## XFCE tweaks (recommended)

- **Enable compositing** so the bar/panels are actually translucent:
  *Settings → Window Manager Tweaks → Compositor → Enable display compositing*.
- **Hide the stock XFCE panel** (optional, to avoid two bars): right-click the panel
  → *Panel → Panel Preferences → uncheck "Lock panel"*, then remove it; or just move
  it to the bottom.
- **PipeWire**: make sure it's running (`systemctl --user status pipewire`), since
  volume uses `wpctl`. If you use plain PulseAudio instead, swap the volume widget to
  `pactl` (see `modules/bar/VolumeWidget.qml`).
- **Brightness**: needs `brightnessctl` (or `xbacklight`). Your user may need to be in
  the `video` group, or use `brightnessctl` which talks to logind.

## Theming

The palette lives in `theme/Theme.qml` and is switchable at launch via the
`RYOKU_XFCE_THEME` env var — no other file needs touching.

| Value | Palette |
| --- | --- |
| `solitude` (default) | Solitude Dark — Ryoku's near-black Material-3 base |
| `mocha` | Catppuccin Mocha |
| `light` | Solitude Light — for bright XFCE sessions |

Set it for your session (e.g. in `~/.xprofile` or `~/.config/xfce4/xinitrc`):

```bash
export RYOKU_XFCE_THEME=mocha
```

then restart the shell: `pkill -f 'qs -c ryoku-xfce'; qs -c ryoku-xfce`. A helper is provided:

```bash
./select-theme.sh mocha
```

> **Note on blur:** true backdrop blur of the desktop *behind* the bar is a
> Wayland (layer-shell) feature. On X11/xfwm4 that protocol doesn't exist, so the
> shell uses a translucent fill plus a `GlassSheen` top-light gradient (in
> `components/GlassSheen.qml`) to evoke Ryoku's frosted glass. If you want real
> blur, run this same config under a Wayland compositor (Hyprland/niri), where
> `PanelWindow` uses wlr-layer-shell.

## Project layout

```
ryoku-xfce/
├── shell.qml                      # entry point: per-screen bars + overlays + IPC
├── install.sh
├── theme/Theme.qml               # Solitude Dark tokens (singleton)
├── components/                    # State singleton, IconButton, Txt, HSlider
└── modules/
    ├── bar/                      # PanelWindow bar + ClockWidget, WorkspacesWidget,
    │                             #   VolumeWidget, BrightnessWidget, NetworkWidget,
    │                             #   BatteryWidget, MediaWidget, TrayWidget
    ├── controlcenter/            # slide-in control center + MediaCard + PowerAct
    ├── launcher/                 # DesktopEntries app grid
    └── powermenu/                # power menu
```

## How the X11 mapping works

- `PanelWindow` is **platform independent**. On X11 Quickshell backs it with
  `XPanelWindow`, which sets the dock window type, applies
  `_NET_WM_STRUT_PARTIAL` to reserve the top strip, and stacks above normal windows —
  so xfwm4 treats the bar like a native panel. No layer-shell needed.
- Overlays (`ControlCenter`, `Launcher`, `PowerMenu`) are `FloatingWindow`s positioned
  on the primary screen's geometry.
- Toggles call the same CLI tools you'd use in a terminal (`nmcli`, `bluetoothctl`,
  `redshift`, `powerprofilesctl`, `wpctl`, `brightnessctl`, `xfce4-session-logout`),
  so behavior matches the rest of your XFCE session.

## Troubleshooting

- **Bar doesn't appear**: confirm X11 (not Wayland) — `echo $XDG_SESSION_TYPE`
  should print `x11`. Ensure `quickshell` is installed and `qs` is on `PATH`.
- **Nothing is translucent**: enable the xfwm4 compositor (see above).
- **No volume/brightness**: install `pipewire`+`wireplumber` and `brightnessctl`,
  and re-run `qs`. Check `qs ipc show` lists `launcher`/`controlcenter`/`powermenu`.
- **Workspace pips missing**: install `wmctrl` (and `xdotool` for the window title).
- **Live-reload**: edit any file and Quickshell hot-reloads. For a clean restart:
  `pkill -f 'qs -c ryoku-xfce'; qs -c ryoku-xfce`.

## License / credit

Visual design adapted from [Ryoku](https://github.com/Ryoku-dev/ryoku) (Solitude Dark
palette, pill/control-center concept). This conversion is original QML written against
the public Quickshell API; it is not affiliated with or endorsed by the Ryoku project.
