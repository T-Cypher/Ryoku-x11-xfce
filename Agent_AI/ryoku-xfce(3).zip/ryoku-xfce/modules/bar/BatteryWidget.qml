// Battery via UPower. Uses the daemon's DisplayDevice aggregate and scans for a
// real laptop battery so desktops don't show a phantom cell. Icons come straight
// from UPower's own icon name (always valid for the current state).
import QtQuick
import Quickshell
import Quickshell.Services.UPower
import Quickshell.Widgets
import qs.theme
import qs.components

Item {
    id: root
    implicitWidth: batRow.implicitWidth
    implicitHeight: batRow.implicitHeight

    property bool hasBattery: false
    property real percent: 0
    property bool charging: false
    property string devIcon: ""

    function update(): void {
        let has = false
        for (let i = 0; i < UPower.devices.values.length; i++) {
            const d = UPower.devices.values[i]
            if (d.isLaptopBattery && d.isPresent) { has = true; break }
        }
        root.hasBattery = has
        const dd = UPower.displayDevice
        if (dd && dd.ready) {
            root.percent = dd.percentage
            // UPowerDeviceState: 1 = Charging, 2 = Discharging, 5 = PendingCharge
            root.charging = dd.state === 1 || dd.state === 5
            root.devIcon = dd.iconName
        }
    }

    visible: root.hasBattery

    Row {
        id: batRow
        spacing: 6
        IconButton {
            icon: root.devIcon || "battery-full"
            tooltip: Math.round(root.percent) + "%" + (root.charging ? " (charging)" : "")
            size: 18
        }
        Txt {
            text: Math.round(root.percent) + "%"
            anchors.verticalCenter: parent.verticalCenter
            color: root.charging ? Theme.accentSoft : Theme.onSurface
        }
    }

    Connections {
        target: UPower
        function onDevicesChanged(): void { root.update() }
    }
    Connections {
        target: UPower.displayDevice
        function onPercentageChanged(): void { root.update() }
        function onStateChanged(): void { root.update() }
        function onIconNameChanged(): void { root.update() }
    }
    Component.onCompleted: root.update()
}
