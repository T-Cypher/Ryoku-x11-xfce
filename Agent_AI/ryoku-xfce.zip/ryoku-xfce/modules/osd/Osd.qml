import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.theme
import qs.components
FloatingWindow {
    id: win; visible: State.osdVisible
    property var scr: Quickshell.screens.length ? Quickshell.screens[0] : null
    width: 280; height: 56; screen: scr; color: "transparent"
    x: scr ? scr.geometry.x + Math.round((scr.geometry.width-width)/2) : 200
    y: scr ? scr.geometry.y + scr.geometry.height - height - 24 : 600
    Rectangle { anchors.fill: parent; radius: Theme.rPill; color: Theme.panelFill; border { width:1; color: Theme.panelBorder } }
    RowLayout { anchors.fill: parent; anchors.margins: 14; spacing: 10
        IconButton { icon: State.osdKind==="brightness" ? "display-brightness" : "audio-volume-high"; highlightOnHover: false }
        HSlider { Layout.fillWidth: true; value: State.osdValue; interactive: false }
        Txt { text: Math.round(State.osdValue*100)+"%" }
    }
}
