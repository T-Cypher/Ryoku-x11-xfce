// Now-playing indicator (Mpris). Shows transport controls + a scrolling
// "Artist – Title". Hidden when no player is running.
import QtQuick
import Quickshell.Services.Mpris
import qs.theme
import qs.components

Item {
    id: root
    implicitWidth: mediaRow.implicitWidth
    implicitHeight: mediaRow.implicitHeight

    property var player: null

    function syncPlayer(): void {
        root.player = Mpris.players.count > 0 ? Mpris.players.get(0) : null
    }

    visible: root.player !== null

    Row {
        id: mediaRow
        spacing: 4
        IconButton {
            icon: "media-skip-backward"
            tooltip: "Previous"
            onClicked: if (root.player) root.player.previous()
        }
        IconButton {
            icon: (root.player && root.player.isPlaying) ? "media-playback-pause" : "media-playback-start"
            tooltip: "Play / Pause"
            onClicked: if (root.player) root.player.playPause()
        }
        IconButton {
            icon: "media-skip-forward"
            tooltip: "Next"
            onClicked: if (root.player) root.player.next()
        }
        Txt {
            text: root.player ? (root.player.trackArtist + " – " + root.player.trackTitle) : ""
            elide: Text.ElideRight
            width: Math.min(240, paintedWidth)
            maximumLineCount: 1
            color: Theme.onSurfaceVariant
            anchors.verticalCenter: parent.verticalCenter
        }
    }

    Connections {
        target: Mpris
        function onPlayersChanged(): void { root.syncPlayer() }
    }
    Component.onCompleted: root.syncPlayer()
}
