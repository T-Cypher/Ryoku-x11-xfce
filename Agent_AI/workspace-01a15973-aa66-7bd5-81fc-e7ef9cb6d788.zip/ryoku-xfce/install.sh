#!/usr/bin/env bash
# Install the Ryoku → Quickshell conversion into ~/.config/quickshell and wire up
# XFCE autostart. Run from the folder that contains this script.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${XDG_CONFIG_HOME:-$HOME/.config}/quickshell"

echo "==> Installing Ryoku-XFCE Quickshell config to: $DEST"
mkdir -p "$DEST"
cp -r "$SRC/shell.qml" "$SRC/theme" "$SRC/components" "$SRC/modules" "$DEST/"

echo "==> Installing XFCE autostart entry"
mkdir -p "$HOME/.config/autostart"
cp "$SRC/assets/quickshell.desktop" "$HOME/.config/autostart/quickshell.desktop"

cat <<'EOF'

==> Done.

Start it now (no log-out needed):
    qs

Or log out / in — XFCE will autostart it.

Recommended dependencies (Arch):
    sudo pacman -S quickshell pipewire wireplumber pipewire-pulse \
        networkmanager brightnessctl bluez bluez-utils upower \
        wmctrl xdotool redshift power-profiles-daemon

Optional editor / launcher icons:
    sudo pacman -S power-profiles-daemon

Keyboard shortcuts (XFCE: Settings → Keyboard → Application Shortcuts):
    Super+Space → qs ipc call launcher toggle
    Super+S     → qs ipc call controlcenter toggle
    Super+Esc   → qs ipc call powermenu toggle

See README.md for the full guide (theming, troubleshooting, disabling the
stock XFCE panel, etc.).
EOF
