// Ryoku-inspired design tokens, adapted for X11 / xfwm4.
//
// Three palettes ship out of the box, selected by the RYOKU_XFCE_THEME env var
// (solitude [default] | mocha | light):
//   - solitude : the original "Solitude Dark" near-black Material-3 base
//   - mocha    : Catppuccin Mocha
//   - light    : a Solitude Light variant for bright XFCE sessions
// Every other component reads these tokens, so switching themes touches nothing
// but this file. Radii / typography are shared across palettes.
pragma Singleton
import QtQuick
import Quickshell

QtObject {
    id: root

    readonly property string themeName: Quickshell.env("RYOKU_XFCE_THEME") || "solitude"

    // --- Palettes -------------------------------------------------------------
    readonly property var palettes: ({
        solitude: {
            surface: "#101315", surfaceVariant: "#1a1d1f",
            surfaceContainerLow: "#1a1d1f", surfaceContainer: "#202428",
            surfaceContainerHigh: "#2c3136", surfaceContainerHighest: "#3a4045",
            inverseSurface: "#cacccc", surfaceTint: "#798186",
            primary: "#798186", primaryContainer: "#1a1d1f", secondary: "#a8adb0",
            tertiary: "#de6145", error: "#de6145",
            outline: "#4a5156", outlineVariant: "#2b3136",
            onSurface: "#e9ebec", onSurfaceVariant: "#a8adb0",
            onPrimary: "#101315", onTertiary: "#101315",
            barFill: "#15181b", barOpacity: 0.86,
            panelFill: "#181c20", panelHover: "#23282c", panelBorder: "#2b3136",
            accent: "#de6145", accentSoft: "#f08a72",
            sheen: "#ffffff", glassTop: 0.10
        },
        mocha: {
            surface: "#1e1e2e", surfaceVariant: "#181825",
            surfaceContainerLow: "#181825", surfaceContainer: "#313244",
            surfaceContainerHigh: "#45475a", surfaceContainerHighest: "#585b70",
            inverseSurface: "#cdd6f4", surfaceTint: "#9399b2",
            primary: "#9399b2", primaryContainer: "#313244", secondary: "#cdd6f4",
            tertiary: "#fab387", error: "#f38ba8",
            outline: "#585b70", outlineVariant: "#45475a",
            onSurface: "#cdd6f4", onSurfaceVariant: "#a6adc8",
            onPrimary: "#1e1e2e", onTertiary: "#1e1e2e",
            barFill: "#1e1e2e", barOpacity: 0.88,
            panelFill: "#181825", panelHover: "#313244", panelBorder: "#45475a",
            accent: "#fab387", accentSoft: "#f9e2af",
            sheen: "#ffffff", glassTop: 0.10
        },
        light: {
            surface: "#f4f5f7", surfaceVariant: "#e7e9ee",
            surfaceContainerLow: "#e7e9ee", surfaceContainer: "#dde0e7",
            surfaceContainerHigh: "#cdd2dc", surfaceContainerHighest: "#bcc3d0",
            inverseSurface: "#1c1f24", surfaceTint: "#7d8694",
            primary: "#5b6470", primaryContainer: "#dde0e7", secondary: "#3d4450",
            tertiary: "#c2410c", error: "#b91c1c",
            outline: "#b6bcc8", outlineVariant: "#cdd2dc",
            onSurface: "#1c1f24", onSurfaceVariant: "#4a525e",
            onPrimary: "#f4f5f7", onTertiary: "#ffffff",
            barFill: "#ffffff", barOpacity: 0.82,
            panelFill: "#fbfcfe", panelHover: "#eef0f4", panelBorder: "#d3d8e0",
            accent: "#c2410c", accentSoft: "#ea580c",
            sheen: "#ffffff", glassTop: 0.55
        }
    })

    readonly property var P: root.palettes[(root.themeName in root.palettes) ? root.themeName : "solitude"]

    // --- Surfaces (per palette) ----------------------------------------------
    readonly property color surface:                 P.surface
    readonly property color surfaceVariant:          P.surfaceVariant
    readonly property color surfaceContainerLow:     P.surfaceContainerLow
    readonly property color surfaceContainer:        P.surfaceContainer
    readonly property color surfaceContainerHigh:    P.surfaceContainerHigh
    readonly property color surfaceContainerHighest: P.surfaceContainerHighest
    readonly property color inverseSurface:          P.inverseSurface
    readonly property color surfaceTint:             P.surfaceTint
    readonly property color primary:                P.primary
    readonly property color primaryContainer:       P.primaryContainer
    readonly property color secondary:              P.secondary
    readonly property color tertiary:               P.tertiary
    readonly property color error:                  P.error
    readonly property color outline:                P.outline
    readonly property color outlineVariant:         P.outlineVariant
    readonly property color onSurface:              P.onSurface
    readonly property color onSurfaceVariant:       P.onSurfaceVariant
    readonly property color onPrimary:              P.onPrimary
    readonly property color onTertiary:             P.onTertiary

    // --- Panel / bar (per palette) ------------------------------------------
    readonly property color barFill:                P.barFill
    readonly property real  barOpacity:             P.barOpacity
    readonly property color panelFill:              P.panelFill
    readonly property color panelHover:             P.panelHover
    readonly property color panelBorder:            P.panelBorder
    readonly property color accent:                 P.accent
    readonly property color accentSoft:            P.accentSoft

    // --- Frosted-glass sheen (used by GlassSheen) ---------------------------
    readonly property color sheen:                  P.sheen
    readonly property real  glassTop:              P.glassTop
    readonly property bool  isLight:               root.themeName === "light"

    // --- Radii (shared) ------------------------------------------------------
    readonly property int rXs: 6
    readonly property int rSm: 10
    readonly property int rMd: 14
    readonly property int rLg: 18
    readonly property int rPill: 22

    // --- Typography (shared) -------------------------------------------------
    readonly property string fontSans: "Inter, \"Noto Sans\", sans-serif"
    readonly property string fontMono: "\"JetBrains Mono\", \"Noto Sans Mono\", monospace"
}
