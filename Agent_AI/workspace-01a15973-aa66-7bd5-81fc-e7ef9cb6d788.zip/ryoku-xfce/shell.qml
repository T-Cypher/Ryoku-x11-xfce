// Ryoku → Quickshell conversion for XFCE (xfwm4) on X11 / Arch.
//
// This is a self-contained shell: it reuses Ryoku's visual language (the Solitude
// Dark palette, the monochrome "sumi" pill, the warm-coral accent, the rounded
// translucent panels) but replaces Ryoku's Wayland/Hyprland + Go-daemon stack with
// portable Quickshell modules and standard Arch tooling (wpctl, nmcli, brightnessctl,
// bluetoothctl, redshift, powerprofilesctl, wmctrl/xdotool, xfce4-session).
//
// On X11, PanelWindow maps to an X11 dock (_NET_WM_STRUT_PARTIAL) so xfwm4 reserves
// the top strip automatically — no layer-shell required.
//@ pragma UseQApplication

import QtQuick
import Quickshell
import Quickshell.Io

import qs.theme
import qs.components
import qs.modules.bar
import qs.modules.controlcenter
import qs.modules.launcher
import qs.modules.powermenu

ShellRoot {
    // One pill bar per connected screen.
    Variants {
        model: Quickshell.screens
        delegate: Component { Bar {} }
    }

    // Overlays (single instances, shown on the primary screen).
    ControlCenter { }
    Launcher { }
    PowerMenu { }

    // IPC toggles — bind these from XFCE's keyboard shortcuts:
    //   qs ipc call launcher toggle
    //   qs ipc call controlcenter toggle
    //   qs ipc call powermenu toggle
    IpcHandler {
        target: "launcher"
        function toggle(): void { State.toggleLauncher() }
        function show(): void { State.launcher = true }
        function hide(): void { State.launcher = false }
    }
    IpcHandler {
        target: "controlcenter"
        function toggle(): void { State.toggleControlCenter() }
        function show(): void { State.controlCenter = true }
        function hide(): void { State.controlCenter = false }
    }
    IpcHandler {
        target: "powermenu"
        function toggle(): void { State.togglePowerMenu() }
        function show(): void { State.powerMenu = true }
        function hide(): void { State.powerMenu = false }
    }
}
