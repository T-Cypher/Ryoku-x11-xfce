// Minimal horizontal slider (avoids QtQuick.Controls so the shell stays light).
// value is 0..1. Drag or click the track to set.
import QtQuick
import qs.theme

Item {
    id: root
    property real value: 0
    property color color: Theme.accent
    signal valueChanged(real v)

    implicitHeight: 6
    implicitWidth: 200

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: Theme.surfaceContainerHigh
    }
    Rectangle {
        width: Math.max(0, Math.min(1, root.value)) * parent.width
        height: parent.height
        radius: height / 2
        color: root.color
    }
    Rectangle {
        x: Math.round(Math.max(0, Math.min(1, root.value)) * parent.width - 7)
        y: -4
        width: 14
        height: 14
        radius: 7
        color: root.color
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        onPressed: (mouse) => setFromX(mouse.x)
        onPositionChanged: (mouse) => { if (pressed) setFromX(mouse.x) }
        function setFromX(x: real): void {
            const v = Math.max(0, Math.min(1, x / parent.width))
            root.value = v
            root.valueChanged(v)
        }
    }
}
