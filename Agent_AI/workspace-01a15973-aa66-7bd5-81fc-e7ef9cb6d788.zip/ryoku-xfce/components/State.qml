// Shared UI state for the whole shell. Every surface binds its visibility to
// one of these flags and every entry point (bar buttons, IPC handlers) flips
// them, so the bar, control center, launcher and power menu stay in sync.
pragma Singleton
import QtQuick

QtObject {
    property bool controlCenter: false
    property bool launcher: false
    property bool powerMenu: false

    function toggleControlCenter(): void { controlCenter = !controlCenter }
    function toggleLauncher(): void { launcher = !launcher }
    function togglePowerMenu(): void { powerMenu = !powerMenu }
    function closeAll(): void {
        controlCenter = false
        launcher = false
        powerMenu = false
    }
}
